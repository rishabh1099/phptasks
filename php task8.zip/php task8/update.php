<?php session_start(); 
if($_SESSION['email']== false){
    header('location: login.php');
}
include 'connection.php';
$ids = $_GET['id'];
$select = "select * from registration where id = '$ids'";
$selectquery = mysqli_query($con, $select);
$get = mysqli_fetch_assoc($selectquery);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/update.css" />
    <title>update</title>
</head>
<body>
<?php
include 'nav.php';
?>
  <div id="container">
        <div id="registration">
            <form  method="POST" id="form" onsubmit="return myfun()">
                <h1>Update </h1>
                <label>Name :</label>
                <input type="text" name="name" id="name" value="<?php echo $get['name']; ?>">
                <p id="sp2"></p>
                <label>Email :</label>
                <input type="text" name="email" id="email" value="<?php echo $get['email']; ?>" disabled>
                <p id="sp3"></p>
                <label>Mobile :</label>
                <input type="number" name="number" id="number" value="<?php echo $get['number']; ?>" disabled>
                <p id="sp4"></p>
                <label>Password :</label>
                <input type="password" name="pass" id="pass" value="<?php echo $get['password']; ?>">
                <p id="sp5"></p>
                <br>
                <button type="submit" name="submit" id="btn">Update</button>
                <label id="status"></label>
                <br>
            </form>
        </div> 
    </div>
    <script>
         function myfun(){
               $("p").css("visibility","hidden");
                var name = $("#name").val();
                var pass = $("#pass").val();
                var reg = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
                var name1 = /^[^\d]+$/;
                if(name.length < 3){
                    $("#sp2").css("visibility","visible");
                    $("#sp2").html("**Invalid Name");
                    return false;
                }else if (reg.test(name) == true) {
                    $("#sp2").css("visibility","visible");
                    $("#sp2").html("**Invalid Name");
                    return false;
                }else if (name1.test(name) == false) {
                    $("#sp2").css("visibility","visible");
                    $("#sp2").html("**Invalid Name");
                    return false;
                }else if (pass.length < 4) {
                    $("#sp5").css("visibility","visible");
                    $("#sp5").html("**Invalid Password");
                    return false;
                }
                else{
                    return true;
                }
        }
        function error(n, letter){
            $(n).css("visibility", "visible");
            $(n).html(letter);
            return false;
        }

        function status(tag, text){
            $(tag).css("display", "block");
            $(tag).html(text);
        }
        $("input").click(function(){
            $("p").css("visibility","hidden");
        })
        $("input").click(function(){
            $("#status").css("display","none");
        })
    </script>
    <?php

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $pass = $_POST['pass'];

    if(strlen($name)< 3){ 
        echo "<script>error('#sp2', 'Invalid Name')</script>";
        return false;
    }else if (!preg_match("/^([a-zA-Z' ]+)$/",$name)) {
        echo "<script>error('#sp2', 'Invalid Name')</script>";
        return false;
    }else if(strlen($pass) < 2){
        echo "<script>error('#sp5', 'Invalid Password')</script>"; 
        return false;
    }else{
        $query1 = "update registration set name = '$name', password = '$pass' where id = '$ids'";
        $get = mysqli_query($con, $query1);
        if($query1){
           
            header('location: home.php');
            echo "<script>alert('data updated')</script>";
        }else{
            echo "<script>alert('data not updated')</script>";
        }
      
    }
}
?>
</body>
</html>