<?php 
$server = 'localhost';
$user = 'root';
$password = '';
$db = 'task8';

$con = mysqli_connect($server, $user, $password, $db);


?>