<div id="nav">
        <h3>Email - <?php echo $_SESSION['email']; ?></h3>
        <h2>Welcome : <?php echo $_SESSION['name']; ?></h2>
        <a href="logout.php" id="logout"><button type="submit"  name="submit">Logout</button></a>
     </div><br>