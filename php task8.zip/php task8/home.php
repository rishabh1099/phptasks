<?php 
session_start();
include 'connection.php';
if($_SESSION['email']== false){
    header('location: login.php');
}
$text = $_SESSION['email'];
$select = "select * from registration where email = '$text'";
$selectquery = mysqli_query($con, $select);
$get = mysqli_fetch_assoc($selectquery);
$_SESSION['name'] = $get['name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        #nav{
            width: 100%;
            display: flex;
            height: 50px;
            background-color: #4d4dff;
        }
        #nav>h2{
            margin-left: auto;
            line-height: 20px;
            color: white;
        }
        #nav>h3{
            margin-right: auto;
            margin-left: 50px;
            line-height: 20px;
            color: white;
        }
        #cont{
            width: 100%;
            height: 200px;
            display: flex;
            align-items: center;
            text-align: center;
            justify-content: center;
            flex-direction: column;
        }
        #logout{
            margin-left:auto;
            margin-right: 100px;
            margin-top: 10px;
        }
        #update{
            width: 100px;
            height: 40px;
        }
    </style>
</head>
<body>
    <?php include 'nav.php' ?>
     <div id="cont">
             <a href="update.php?id=<?php echo $_SESSION['id']; ?>"><button id="update" >Update</button></a>
     </div>
    
</body>
</html>