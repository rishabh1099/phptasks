<?php 
session_start();
include 'connection.php';
if(!$_SESSION['email']){
    header('location: login.php');
}else{
  $text = $_SESSION['email'];
  $type = $_SESSION['type'];
  $ids =  $_SESSION['id'];
 
}
if($type == 'User'){
   header('location: logout.php');
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>profile</title>
   <style>
    
   </style>
</head>
<body>
   <?php include 'header.php'; ?>
  <?php include 'navbar.php'; ?>
   <div id="container">
   <form  id="form1" method="POST" enctype="multipart/form-data">
            <label>Product Name :</label><br>
            <input type="text" id="user" name="name" required><br>
            <label>Product Category :</label><br>
            <input type="text" name="category" required><br>
            <label>Price :</label><br>
            <input type="number" name="price" required><br>
           
            <input type="file" name="img" required><br>
            <br>
            <button type="submit" name="submit"/>Add Product </button>
            
        </form>
     <?php 
     if(isset($_POST['submit'])){
       $name = $_POST['name'];
       $category = $_POST['category'];
       $price = $_POST['price'];
       $img = $_FILES['img']['name'];
       $image = "images/".time().$img;
       move_uploaded_file($_FILES['img']['tmp_name'], $image );
       $insert = "INSERT INTO `products`(`product_name`, `product_image`, `product_category`, `product_price`)
        VALUES ('$name','$image','$category','$price')";
        $insertquery = mysqli_query($con, $insert);
        if($insertquery){
           header('location:home.php');
        }
     }
     ?>
   </div>
   <?php 
     include 'phpFooter.php';
   ?>

</body>
</html>