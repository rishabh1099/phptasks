<?php 
session_start();
include 'connection.php';
if($_SESSION['email']== false){
    header('location: login.php');
}
$text = $_SESSION['email'];
$type = $_SESSION['type'];
$ids =  $_SESSION['id'];
if($type == 'User'){
  header('location: logout.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>profile</title>
   <style>
    
   </style>
</head>
<body>
   <?php include 'header.php'; ?>
  <?php include 'navbar.php'; ?>
   <div id="container">
     
     <table>
       <tr>
         <th>User Id</th>
         <th>User Name</th>
         <th>Email</th>
         <th>Password</th>
       </tr>
       <?php 
       $select = "select * from registration";
       $selectquery = mysqli_query($con, $select);
       while($fetch = mysqli_fetch_array($selectquery)){
         ?>
        <tr>
        <td><?php echo $fetch['id']; ?></td>
        <td><?php echo $fetch['name']; ?></td>
        <td><?php echo $fetch['email']; ?></td>
        <td><?php echo $fetch['password']; ?></td>
       
      </tr>
      <?php
       }
       ?>
       
     </table>
   </div>
   <?php 
     include 'phpFooter.php';
   ?>

</body>
</html>