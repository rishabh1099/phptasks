<?php 
session_start();
include 'connection.php';
if($_SESSION['email']== false){
    header('location: login.php');
}
$text = $_SESSION['email'];
$type = $_SESSION['type'];
$ids =  $_SESSION['id'];
if($type == 'User'){
  header('location: logout.php');
}
$ids = $_GET['id'];
$select = "select * from products where product_id = '$ids'";
$selectquery = mysqli_query($con, $select);
$get = mysqli_fetch_assoc($selectquery);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>update</title>
   <style>
    
   </style>
</head>
<body>
   <?php include 'header.php'; ?>
  <?php include 'navbar.php'; ?>
   <div id="container">
     
   <form  id="form1" method="POST" enctype="multipart/form-data">
            <label>Product Name :</label><br>
            <input type="text" id="user" name="name" value="<?php echo $get['product_name']; ?>" required><br>
            <label>Product Category :</label><br>
            <input type="text" name="category" value="<?php echo $get['product_category']; ?>" required><br>
            <label>Price :</label><br>
            <input type="number" name="price" value="<?php echo $get['product_price']; ?>" required><br>
           
            <input type="file" name="img"><br>
            <br>
            <button type="submit" name="submit"/>Update Product </button>
            
        </form>
     <?php 
     if(isset($_POST['submit'])){
         
       $name = $_POST['name'];
       $category = $_POST['category'];
       $price = $_POST['price'];
       $img = $_FILES['img']['name'];
       if($img == ""){
        $update = "UPDATE products set product_name = '$name', product_category = '$category',
         product_price = '$price' where product_id = '$ids'";
        $updatequery = mysqli_query($con, $update);
        header('location:allProducts.php');
       }else{
        $image = "images/".time().$img;
        move_uploaded_file($_FILES['img']['tmp_name'], $image );
        $update = "UPDATE products set product_name = '$name', product_category = '$category',
        product_price = '$price', product_image = '$image' where product_id = '$ids'";
        $updatequery = mysqli_query($con, $update);
        header('location:allProducts.php');
       }
       
     }
     ?>
    
   </div>
   <?php 
     include 'phpFooter.php';
   ?>

</body>
</html>