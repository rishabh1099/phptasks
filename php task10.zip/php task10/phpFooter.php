<?php

if($type == 'User'){
    ?>
    <script>
       document.getElementById('add').style.display = "none";
      document.getElementById('del').style.display = "none";
      document.getElementById('users').style.display = "none";
      document.getElementById('update').style.display = "none";
    </script>
    <?php
   
}else{
   ?>
    <script>
      document.getElementById('update').style.display = "inline-block";
       document.getElementById('add').style.display = "inline-block";
      document.getElementById('del').style.display = "inline-block";
      document.getElementById('users').style.display = "inline-block";
    </script>
    <?php
}

?>