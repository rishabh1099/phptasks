<?php 
session_start();
include 'connection.php';
if(!$_SESSION['email']){
    header('location: login.php');
}else{
  $text = $_SESSION['email'];
  $type = $_SESSION['type'];
  $ids =  $_SESSION['id'];
  $select = "select * from registration where email = '$text'";
  $selectquery = mysqli_query($con, $select);
  $get = mysqli_fetch_assoc($selectquery);
  $_SESSION['name'] = $get['name'];
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>profile</title>
   <style>
    
   </style>
</head>
<body>
   <?php include 'header.php'; ?>
  <?php include 'navbar.php'; ?>
   <div id="container">
     <table>
         <?php
         $select = "select product_category from products Group by product_category";
         $selectquery = mysqli_query($con, $select);
            while($fetch = mysqli_fetch_array($selectquery)){
                ?>
                <tr>
                <th colspan="4"><?php echo $fetch['product_category']; ?></th>
                </tr>
                <tr>
                <?php
                $selectt = "select * from products where product_category = '{$fetch['product_category']}'";
                 $selectqueryy = mysqli_query($con, $selectt);
                 while($fetchh = mysqli_fetch_array($selectqueryy)){
                     ?>
                   
                    <td>
                        <h4><?php echo $fetchh['product_name']; ?></h4><br>
                        <img src="<?php echo $fetchh['product_image']; ?>" /><br>
                        <h4><?php echo $fetchh['product_price']; ?></h4><br>
                        <a href="updateproduct.php?id=<?php echo $fetchh['product_id'] ?>"><button type="button" class="btnn">Update</button></a>
                    </td>
                  <?php
                 }
                ?>
                
                </tr>
                <?php
            }
         ?>
         
        
     </table>
     <?php 
     if($type == 'User'){
        ?>
        <script>
            var n = document.getElementsByClassName('btnn');
            for(i=0; i<n.length; i++){
                n[i].style.display = "none";
            }
        </script>
        <?php
      }else{
        ?>
        <script>
            var n = document.getElementsByClassName('btnn');
            for(i=0; i<n.length; i++){
                n[i].style.display = "inline-block";
            }
        </script>
        <?php
      }
     ?>
   </div>
   <?php 
     include 'phpFooter.php';
   ?>

</body>
</html>