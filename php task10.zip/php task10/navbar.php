<div id="nav">
       <ul>
           <li><a href="home.php">Dashboard</a></li>
           <li><a href="allProducts.php" id="update">Update Products</a></li>
           <li><a href="allProducts.php" id="all">View All Products</a></li>
           <li id="add" ><a href="add.php">Add Products</a></li>
           <li id="del"><a href="delete.php">Delete Products</a></li>
           <li id="users"><a href="users.php">View registered users</a></li>
       </ul>
   </div>  