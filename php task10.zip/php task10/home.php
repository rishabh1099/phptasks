<?php 
session_start();
include 'connection.php';
if(!$_SESSION['email']){
    header('location: login.php');
}else{
  $text = $_SESSION['email'];
  $type = $_SESSION['type'];
  $ids =  $_SESSION['id'];
  $select = "select * from registration where email = '$text'";
  $selectquery = mysqli_query($con, $select);
  $get = mysqli_fetch_assoc($selectquery);
  $_SESSION['name'] = $get['name'];
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>profile</title>
   <style>
    
   </style>
</head>
<body>
   <?php include 'header.php'; ?>
  <?php include 'navbar.php'; ?>
   <div id="container">
     <h1 id="head"><?php echo $_SESSION['email']; ?></h1>
     
   </div>
   <?php 
     include 'phpFooter.php';
   ?>

</body>
</html>