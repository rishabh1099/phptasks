<?php include 'connection.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title>register</title>
</head>
<body>
    <div id="container" >
        <form method="POST" onsubmit="return myfun()"><br><br> 
            <h1>Registration</h1>
            <label>Name :</label>
            <input type="text" name="name" id="name">
            <span id="sp1"></span>
            <label>Email :</label>
            <input type="email" name="email" id="email">
            <span id="sp2"></span>
            <label>Password :</label>
            <input type="text" name="pass" id="password">
            <span id="sp3"></span><br>
            <button type="submit" name="submit" id="btn">Register</button><a href="login.php" style="margin-left: 25%; margin-top: -20px;">login</a><br>
            <p id="status" style="margin-left: 10%; height: 20px;"></p>
            <br>
        </form>
    </div>
    <script>
        var tag = document.getElementsByTagName('input');
        for(var i=0; i<tag.length; i++){
            tag[i].setAttribute("required", "");
            tag[i].onclick = hidden;
        }
            function hidden(){
                var span = document.getElementsByTagName('span');
                for(var i=0; i<span.length; i++){
                span[i].style.visibility = "hidden";
                }
            }
        function myfun(){
           hidden();
            var name = document.getElementById('name').value;
            var email = document.getElementById('email').value;
            var pass = document.getElementById('password').value;
            var reg = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
            var mail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            var name1 = /^[^\d]+$/;

            if(name.length < 3){
                document.getElementById('sp1').style.visibility = "visible";
                document.getElementById('sp1').innerHTML = "**Invalid Name";
                return false;
            }else if (reg.test(name)== true){
                document.getElementById('sp1').style.visibility = "visible";
                document.getElementById('sp1').innerHTML = "**Invalid Name";
                return false;
            }else if (name1.test(name)== false){
                document.getElementById('sp1').style.visibility = "visible";
                document.getElementById('sp1').innerHTML = "**Invalid Name";
                return false;
            }else if (mail.test(email)==false){
                document.getElementById('sp2').style.visibility = "visible";
                document.getElementById('sp2').innerHTML = "**Invalid Email";
                return false;
            }else if(pass.length < 4){
                document.getElementById('sp3').style.visibility = "visible";
                document.getElementById('sp3').innerHTML = "**Invalid password";
                return false;
            }else{
                return true;
            }
        }
        function error(n, letter){
            document.getElementById(n).style.visibility = "visible";
            document.getElementById(n).innerHTML = letter;
        }

        function result(text){
                document.getElementById('status').innerHTML = text;
                document.getElementById('status').style.background = "green";
        }
    </script>
    <?php
    if(isset($_POST['submit'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $pass = $_POST['pass'];
    
        if(strlen($name)< 3){      
            echo "<script>error('sp1', 'Invalid Name')</script>";
            return false;
        }else if (!preg_match("/^([a-zA-Z' ]+)$/",$name)) {
            echo "<script>error('sp1', 'Invalid Name')</script>";
            return false;
        }else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            echo "<script>error('sp2', 'Invalid Email')</script>";
            return false;
        } else if(strlen($pass) < 4){
            echo "<script>error('sp3', 'Invalid Password')</script>"; 
            return false;
        
        }else{
            $query1 = "select * from registration where email = '$email'";
            $check = mysqli_query($con, $query1);
            if(mysqli_num_rows($check) > 0){
                echo "<script>alert('Email already registered')</script>";
                return false;
            }else{
               $query2 = "insert INTO registration (name, email, password, user_type) Values ('$name', '$email', '$pass', 'User')";
               $insertquery = mysqli_query($con,$query2);
               if($insertquery){
                   echo "<script>result('Registered')</script>";
               }else{
                echo "<script>result('NOt Registered')</script>";
               }
            }
        }
    }
    ?>
    
   
</body>
</html>