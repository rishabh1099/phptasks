<div id="top">
        <h1>Welcome <?php echo $_SESSION['name']; ?></h1>
        <a href="logout.php" id="btn"><button>logout</button></a>
   </div>