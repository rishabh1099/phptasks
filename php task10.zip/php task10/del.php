<?php 
session_start();
include 'connection.php';
if($_SESSION['email']== false){
    header('location: login.php');
}
$ids = $_POST['id'];
$delete = "Delete from products where product_id = '$ids'";
$deletequery = mysqli_query($con, $delete);
if($deletequery){
    echo "1";
}
?>